#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <windows.h>

using namespace std;

// struct buku
struct Book {
    int stock;
    string id, judul, pengarang, penerbit;
};

// Fungsi untuk menampilkan buku dari databse
void tampilBuku();

// Fungsi untuk menambah buku ke databse
void tambahBuku();

// Fungsi untuk mencari data buku
void cariBuku();

// Fungsi untuk mengedit data buku
void editBuku();

// Fungsi untuk menghapus data buku dari databse
void hapusBuku();

// Fungsi untuk menampilkan data peminjam dari databse
void tampilPeminjam();

// Fungsi untuk menampilkan menu admin
void admin();

// Fungsi untuk menontroll login admin
void authAdmin();

// Fungsi untuk mengontroll peminjaman
void pinjamBuku();

// Fungsi untuk menampilkan menu awal program
void home();


int main() {
    bool status = true;
    char opt;

    do {
        home();
        
        cout << "  Apakah ingin kembali ke menu awal? [y/n]: ";
        cin >> opt;

        if((opt == 'n') || (opt == 'N')) status = false;

    } while(status);

    return 0;
}

void home(){
    system("cls");
    int opt;
    cout << "+==========================+\n"
         << "|\t PERPUSTAKAAN \t   |\n"
         << "+==========================+\n"
         << "| 1. Lihat Daftar Buku     |\n"
         << "| 2. Lihat Daftar Peminjam |\n"
         << "| 3. Cari Buku             |\n"
         << "| 4. Pinjam Buku           |\n"
         << "| 5. Login Admin           |\n"
         << "| 6. Keluar                |\n"
         << "+==========================+\n";

    reOption:
    cout << "  Masukkan Pilihan: ";
    cin >> opt;

    if((opt >= 1) && (opt <= 6)) {
        switch(opt) {
            case 1:
                tampilBuku();
                break;
            case 2:
                tampilPeminjam();
                break;
            case 3:
                cariBuku();
                break;
            case 4:
                pinjamBuku();
                break;
            case 5:
                authAdmin();
                break;
            case 6:
                exit(0);
                break;
        }
    } else {
        cout <<  "Pilihan tidak valid, silahkan masukkan lagi\n";
        //Sleep(1000);
        goto reOption;
    }
         
};
void tampilBuku(){
    system("cls");

    ifstream data;
    data.open("database/buku.csv");

    if(!data.is_open()) {
        cout << "Database buku tidak ditemukan! \n";
        exit(0);
    }

    /*
        TODO : Check apa data yang ada di database kosong atau tidak
    */

    //string isEmptyData;

    //getline(data, isEmptyData, ',');

    cout << "+=======================================================================+\n"
         << "|\t\t\t\tDAFTAR BUKU\t\t\t\t|\n"
         << "+=======================================================================+\n";


    //if(isEmptyData == "") {
    //    cout << "| Tidak Ada Buku \t\t\t\t\t\t\t|\n"
    //         << "+=======================================================================+\n";
    //} else {

        string id, judul, pengarang, penerbit, stock;
        string line;
        //getline(data, line);
        //cout << line << endl;
        

        while(data.good()) {
    
            getline(data, line);

            stringstream ss(line);

            getline(ss, id, ',');
            getline(ss, judul, ',');
            getline(ss, pengarang, ',');
            getline(ss, penerbit, ',');
            getline(ss, stock);

            //cout << endl << line;
            Sleep(500);
            if(line != "") {
                cout << "| ID Buku\t: " << id << endl
                     << "| Judul Bukut\t: " << judul << endl
                     << "| Pengarang\t: " << pengarang << endl
                     << "| Penerbit\t: " << penerbit << endl
                     << "| Stock Buku\t: " << stock << endl;
                cout << "+=======================================================================+\n";
            } 
        }
    //}

    data.close();
};
void tambahBuku(){
    bool status = true;
    char opt;

    while(status) {

        ofstream data;
        data.open("database/buku.csv", ios::app);

        if(!data.is_open()) {
            cout << "Database buku tidak ditemukan! \n";
            exit(0);
        }
        
        Book addBuku;
        int jumlah;

        cout << endl
             << "  Tambah Buku Perpustakaan\n"
             << "  Masukkan Jumlah Buku: ";

        cin >> jumlah;

        for(int i = 0; i < jumlah; i++) {

            cout << "\n  Masukkan ID Buku\t: ";
            cin >> addBuku.id;
            cin.ignore();
            cout << "  Masukkan Judul Buku\t: ";
            getline(cin, addBuku.judul);
            cout << "  Masukkan Pengarang\t: ";
            getline(cin, addBuku.pengarang);
            cout << "  Masukkan Penerbit\t: ";
            getline(cin, addBuku.penerbit);
            cout << "  Masukkan Stock Buku\t: ";
            cin >> addBuku.stock;

            data << addBuku.id << ","
                 << addBuku.judul << ","
                 << addBuku.pengarang << ","
                 << addBuku.penerbit << ","
                 << addBuku.stock << "\n";
        }

        data.close();

        cout << "  Ingin melanjutkan tambah data? [y/n]: ";
        cin >> opt;

        if((opt == 'n') || (opt == 'N')) status = false;
    }
    
};
void cariBuku(){
    cin.ignore();
    bool status = true;
    char opt;

    while(status) {
        system("cls");

        ifstream data;
        data.open("database/buku.csv");

        if(!data.is_open()) {
            cout << "Database buku tidak ditemukan! \n";
            exit(0);
        }

        cout << "+=======================================================================+\n"
            << "|\t\t\t\t PENCARIAN\t\t\t\t|\n"
            << "+=======================================================================+\n";

            string id, judul, pengarang, penerbit, stock,
                line, cari;
            int countCari = 0;

            cout << "|  Masukkan kata Kunci: ";
            getline(cin, cari);
            cout << "+=======================================================================+\n";
            

            while(data.good()) {

                getline(data, line);
                stringstream ssline(line);

                getline(ssline, id, ',');
                getline(ssline, judul, ',');
                getline(ssline, pengarang, ',');
                getline(ssline, penerbit, ',');
                getline(ssline, stock);

                string tmp;
                
                stringstream ssjudul(judul);
                stringstream sspengarang(pengarang);
                stringstream sspenerbit(penerbit);


                if( line != "" ) {
                    while(getline(ssjudul, tmp, ' ') || getline(sspengarang, tmp, ' ') || getline(sspenerbit, tmp, ' ')) {
                        //cout << "Judul: " << tmp;
                        if((cari == tmp) ||(cari == id) || (cari == judul) || (cari == pengarang) || (cari == penerbit)) {
                            cout << "| ID Buku\t: " << id << endl
                                 << "| Judul Bukut\t: " << judul << endl
                                 << "| Pengarang\t: " << pengarang << endl
                                 << "| Penerbit\t: " << penerbit << endl
                                 << "| Stock Buku\t: " << stock << endl;
                            cout << "+=======================================================================+\n";
                            countCari = 1;
                            break;
                        }
                    }
                }
                
            }

            if((countCari == 0)) cout << "\n  Data yang dicari tidak ada. Buku " << "\"" << cari << "\"" << " tidak ditemukan \n\n";


        data.close();

        cout << "  Ingin melanjutkan pencarian? [y/n]: ";
        cin >> opt;
        cin.ignore();
        
        if((opt == 'n') || (opt == 'N')) status = false;
    }
}
void editBuku(){
    cout << "  Halaman Edit Buku\n";
};
void hapusBuku(){
    cout << "  Halaman Hapus Buku\n";
};
void tampilPeminjam(){
    cout << "  Halaman Tampil Peminjam\n";
};
void admin(){
    bool status = true;
    char opt;

    while(status) {
        system("cls");
        int option;
        cout << "+==========================+\n"
             << "|      ADMINISTRATOR       |\n"
             << "+==========================+\n"
             << "| 1. Lihat Daftar Buku     |\n"
             << "| 2. Tambah Buku           |\n"
             << "| 3. Edit Buku             |\n"
             << "| 4. Hapus Buku            |\n"
             << "| 5. Logout                |\n"
             << "+==========================+\n";

        reOption:
        cout << "  Masukkan Pilihan: ";
        cin >> option;

        if((option >= 1) && (option <= 6)) {
            switch(option) {
                case 1:
                    tampilBuku();
                    break;
                case 2:
                    tambahBuku();
                    break;
                case 3:
                    editBuku();
                    break;
                case 4:
                    hapusBuku();
                    break;
                case 5:
                    home();
                    break;
            }
        } else {
            cout <<  "Pilihan tidak valid, silahkan masukkan lagi\n";
            //Sleep(1000);
            goto reOption;
        }

        cout << "  Apakah ingin melanjutkan ke menu Admin? [y/n]: ";
        cin >> opt;

        if((opt == 'n') || (opt == 'N')) status = false;
    }
};
void authAdmin(){
    bool status = true;
    char opt;
    
    while(status) {
        string username, password;

        cout << "\n  Login Administrator \n";
        relogin:
        cout << "  Masukkan Username: ";
        cin >> username;
        cout << "  Masukkan Passowrd: ";
        cin >> password;

        if((username == "admin") && (password == "admin")) {
            Sleep(1000);
            admin();
        } else {
            Sleep(1000);
            cout << "  Username atau Password salah! Silahkan cek ulang\n";
            goto relogin;
        }

        cout << "  Anda telah keluar, Apakah ingin login kembali? [y/n]: ";
        cin >> opt;
        
        if((opt == 'n') || (opt == 'N')) status = false;
    }
};
void pinjamBuku(){
    cout << "  Halaman Pinjam Buku\n";
};
